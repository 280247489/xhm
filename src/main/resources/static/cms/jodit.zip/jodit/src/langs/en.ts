export default {
    'Type something': 'Start writing...',
};
